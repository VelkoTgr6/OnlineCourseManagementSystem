﻿namespace OnlineCourseManagementSystem.Core
{
    public class Class1
    {

    }
}
