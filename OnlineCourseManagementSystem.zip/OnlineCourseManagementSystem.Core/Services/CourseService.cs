﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using OnlineCourseManagementSystem.Core.Contracts;
using OnlineCourseManagementSystem.Core.Models.Course;
using OnlineCourseManagementSystem.Infrastructure.Data.Common;
using OnlineCourseManagementSystem.Infrastructure.Data.Models;

namespace OnlineCourseManagementSystem.Core.Services
{
    public class CourseService : ICourseService
    {
        private readonly IRepository repository;
        private readonly ILogger<CourseService> logger;

        public CourseService(IRepository _repository,ILogger<CourseService> _logger)
        {
            repository = _repository;
            logger = _logger;
        }

        public async Task AddAsync(Course courseEntity)
        {
            await repository.AddAsync(courseEntity);

            logger.LogInformation($"Added new course with Title: {courseEntity.Title}");

            await repository.SaveChangesAsync();
        }

        public async Task<IEnumerable<CourseViewModel>> GetAllAsync()
        {
            return await repository.All<Course>()
                .Where(c => !c.IsDeleted)
                .Include(c => c.EnrolledStudents)
                .Select(c => new CourseViewModel
                {
                    Id = c.Id,
                    Title = c.Title,
                    StartDate = c.StartDate,
                    EndDate = c.EndDate,
                    EnrollmentCap = c.EnrollmentCap,
                    EnrolledCount = c.EnrolledStudents.Count
                })
                .ToListAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var course = await repository.GetByIdAsync<Course>(id);

            if (course == null || course.IsDeleted)
            {
                logger.LogWarning($"Attempted to delete missing/deleted course with ID: {id}");
                throw new KeyNotFoundException($"Course with id {id} not found or deleted.");
            }

            course.IsDeleted = true;
            await repository.SaveChangesAsync();
        }

        public Task<bool> ExistsAsync(int id)
        {
            var exists = repository.AllAsReadOnly<Course>()
                .AnyAsync(c => c.Id == id && !c.IsDeleted);

            return exists;
        }

        public async Task<CourseViewModel?> GetByIdAsync(int id)
        {
            var course = await repository.All<Course>()
                .Include(c => c.EnrolledStudents)
                .FirstOrDefaultAsync(c => c.Id == id && !c.IsDeleted);

            if (course != null)
            {
                var dto = new CourseViewModel
                {
                    Id = course.Id,
                    Title = course.Title,
                    StartDate = course.StartDate,
                    EndDate = course.EndDate,
                    EnrollmentCap = course.EnrollmentCap,
                    EnrolledCount = course.EnrolledStudents.Count
                };

                return dto;
            }
            throw new KeyNotFoundException($"Course with id {id} not found.");
        }

        public async Task<int> UpdateAsync(UpdateCourseFormModel courseEntity)
        {
            var course = await repository.GetByIdAsync<Course>(courseEntity.Id);

            if (course == null || course.IsDeleted)
            {
                logger.LogWarning($"Attempted to update missing/deleted course with ID: {courseEntity.Id}");
                throw new KeyNotFoundException($"Course with id {courseEntity.Id} not found.");
            }

            ValidateCourseDates(courseEntity.StartDate, courseEntity.EndDate);

            course.Title = courseEntity.Title;
            course.StartDate = courseEntity.StartDate;
            course.EndDate = courseEntity.EndDate;
            course.EnrollmentCap = courseEntity.EnrollmentCap;

            await repository.SaveChangesAsync();

            logger.LogInformation($"Updated course with Id: {course.Id}");

            return courseEntity.Id;
        }

        public async Task<int> CreateAsync(CreateCourseFormModel courseEntity)
        {
            ValidateCourseDates(courseEntity.StartDate,courseEntity.EndDate);

            var course = new Course()
            {
                Title = courseEntity.Title,
                StartDate = courseEntity.StartDate,
                EndDate = courseEntity.EndDate,
                EnrollmentCap= courseEntity.EnrollmentCap,
            };

            

            await repository.AddAsync(course);
            await repository.SaveChangesAsync();

            logger.LogInformation($"Created course with Id: {course.Id}");

            return course.Id;
        }

        private void ValidateCourseDates(DateTime start, DateTime end)
        {
            if (end <= start)
                throw new InvalidOperationException("EndDate must be after StartDate.");
        }
    }
}
