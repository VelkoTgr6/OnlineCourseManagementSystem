﻿using Microsoft.AspNetCore.Mvc;
using OnlineCourseManagementSystem.Core.Contracts;

namespace OnlineCourseManagementSystem.Api.Controllers
{
    public class CourseController : ControllerBase
    {
        private readonly ILogger<CourseController> logger;
        private readonly ICourseService courseService;

        public CourseController(ICourseService _courseService)
        {
            courseService = _courseService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var courses = await courseService.GetAllAsync();
            return Ok(courses);
        }
    }
}
