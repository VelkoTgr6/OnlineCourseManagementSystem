﻿namespace OnlineCourseManagementSystem.Api.Middleware
{
    public record class ErrorResponse(string Message,int StatusCode,string ErrorType)
    {

    }
}
